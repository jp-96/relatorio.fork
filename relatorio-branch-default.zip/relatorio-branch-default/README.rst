#########
Relatorio
#########

Relatorio is a templating library which provides a way to easily generate
various kinds of documents (odt, ods, png, svg, ...) from a template.
Support for more filetypes can be added by creating plugins for them.

Relatorio also provides a report repository allowing you to link python objects
and reports together, and find reports by mimetype/name/python object.
