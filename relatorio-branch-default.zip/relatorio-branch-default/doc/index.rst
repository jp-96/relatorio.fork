.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   quickexample
   indepthexample
   releases
