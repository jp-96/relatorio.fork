.. _releases-index:

=============
Release notes
=============

.. include:: ../CHANGELOG
